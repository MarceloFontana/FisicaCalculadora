import kotlin.math.pow


class Fisica {
    fun forcaPeso(massa: Float, gravidade: Float): Float {
        return massa * gravidade
    }
    fun forcaCentripeta(massa: Float, raio: Float, velocidade: Float): Float {
        return massa * (velocidade.pow(velocidade) / raio)
    }
    fun impulso (forca: Float, tempoInicial: Float, tempoFinal: Float): Float {
       return forca * (tempoFinal - tempoInicial)
    }
    fun forcaElastica (constanteElastica: Float, deformacao: Float ): Float {
        return constanteElastica * deformacao
    }
    fun velocidadeMedia (posicaoInicial: Float, posicaoFinal: Float, tempoFinal: Float, tempoInicial: Float): Float{
        return (posicaoFinal - posicaoInicial) / (tempoFinal - tempoInicial)
    }
    fun mru (posicaoInicial: Float, tempo: Float,  velocidadeInicial: Float): Float {
        return posicaoInicial + velocidadeInicial * tempo
    }
    fun mruv (posicaoInicial: Float, tempo: Float,  velocidadeInicial: Float, aceleracao: Float): Float {
        return posicaoInicial + velocidadeInicial * tempo + (aceleracao * tempo.pow(tempo)) / 2
    }
}